$(document).ready(function(){
	$('.bxslider').bxSlider({
	  mode: 'fade',
	  captions: true,
	  
	});
});